<?php
/**
 * ------------------------------
 * Initializes all custom widgets
 *
 * @package Neville
 * ------------------------------
 */

// Posts
require_once( NEVILLE_WIDGETS . 'posts/posts.php' );
require_once( NEVILLE_WIDGETS . 'posts/posts-tmpl.php' );
